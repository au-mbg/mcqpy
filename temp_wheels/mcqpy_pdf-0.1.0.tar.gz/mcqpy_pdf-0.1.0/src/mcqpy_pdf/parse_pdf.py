import re
from pathlib import Path
from pypdf import PdfReader

from mcqpy_core.grading.types import ParsedQuestion, ParsedSet
import contextlib
from io import StringIO


class MCQPDFParser:
    def parse_pdf(
        self, student_answer: str | Path, regex_pattern: str | None = None
    ) -> str:
        stdout_capture = StringIO()
        stderr_capture = StringIO()

        with (
            contextlib.redirect_stdout(stdout_capture),
            contextlib.redirect_stderr(stderr_capture),
        ):
            reader = PdfReader(student_answer)
            fields = reader.get_fields()

        split_by_id = self._split_by_id(fields)
        student_info = self._find_student_info(
            fields, regex_pattern=regex_pattern, filename=student_answer
        )
        parsed_questions = self._parse_questions(split_by_id)

        # Make ParsedQuestion objects
        parsed_set = ParsedSet(
            student_info=student_info,
            questions=parsed_questions,
            file=str(student_answer),
        )

        return parsed_set

    def _split_by_id(self, fields):
        split_by_id = {}
        for name, field in fields.items():
            # Find the id in the field name
            qid_start = name.find("qid")
            if qid_start == -1:
                continue  # Not a question field, hopefully.

            qid = name[qid_start + 4 :]  # +4 to skip 'qid='

            if qid not in split_by_id:
                split_by_id[qid] = [(name, field)]
            else:
                split_by_id[qid].append((name, field))
        return split_by_id

    def _find_student_info(self, fields, regex_pattern=None, filename=None):
        student_info = {}

        if not regex_pattern:
            for name, field in fields.items():
                if name == "studentname":
                    student_info["student_name"] = field.get("/V")
                elif name == "studentid":
                    student_info["student_id"] = field.get("/V")
        else:
            pattern = re.compile(regex_pattern)
            match = pattern.match(Path(filename).name)
            if match:
                student_info.update(match.groupdict())

        # Try some type conversions: Prefer int over str
        for key, value in student_info.items():
            if isinstance(value, str) and value.isdigit():
                student_info[key] = int(value)

        return student_info

    def _parse_questions(self, split_by_id):
        parsed = []
        for qid, entries in split_by_id.items():
            slug = None
            answers = []
            onehot = []
            for name, field in entries:
                # Find the slug in the field name
                slug_start = name.find("slug")
                if slug_start != -1:
                    slug = name[slug_start + 5 :]  # +5 to skip 'slug='

                # Find the answer index in the field name
                opt_start = name.find("opt")
                if opt_start != -1:
                    opt_str = name[opt_start + 4 :].split("-")[0]  # +4 to skip 'opt='
                    opt_index = int(opt_str)
                    if field.get("/V") == "/Yes":
                        answers.append(opt_index)
                        onehot.append(1)
                    else:
                        onehot.append(0)

            parsed.append(
                ParsedQuestion(qid=qid, slug=slug, answers=answers, onehot=onehot)
            )

        return parsed
