"""PDF utility helpers."""
