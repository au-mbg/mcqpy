from mcqpy.question import Question
from pathlib import Path

for path in Path.cwd().glob('*.yaml'):
    try:
        q = Question.load_yaml(path)
    except Exception as e:
        print(f"Error loading {path}: {e}")