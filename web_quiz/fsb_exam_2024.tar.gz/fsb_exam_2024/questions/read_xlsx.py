import pandas as pd
from mcqpy.question import Question

df = pd.read_excel('multiple_choice_2024.xlsx')

for index, row in enumerate(df.itertuples(index=False)):
    question_text = row.Q

    # Split question text at a. b. c. d. and e. 
    choices = []
    split_choices = question_text.split('a.')
    question_text = split_choices[0].strip()
    if len(split_choices) > 1:
        for choice_part in split_choices[1:]:
            for label in ['b.', 'c.', 'd.', 'e.']:
                if label in choice_part:
                    choice, remainder = choice_part.split(label, 1)
                    choices.append(choice.strip())
                    choice_part = remainder
            choices.append(choice_part.strip())

    # The correct is the one where there is a one in the corresponding column
    correct_answer = None
    for idx, label in enumerate(['a', 'b', 'c', 'd', 'e']):
        if getattr(row, label.upper()) == 1:
            correct_answer = label
    
    # Turn into index for correct answer: 
    if correct_answer is None:
        raise ValueError("No correct answer found.")
    correct_answer_index = [ord(correct_answer) - ord('a')]

    # Generate a slug: 
    slug = f'exam_2024_question_{index+1}'

    question = Question(
        text=question_text,
        choices=choices,
        slug=slug,
        correct_answers=correct_answer_index, 
        question_type="single",
    )

    yaml = question.as_yaml()
    with open(f'{slug}.yaml', 'w') as f:
        f.write(yaml)

    # Try to read back:
    question_loaded = Question.load_yaml(f'{slug}.yaml')
